<template>
  <div class="about">
   uwqdw
  </div>
</template>
<script>
export default {
  data(){},
  methods:{
    created(){
      console.log(this.$route,88888)
    }

  }
  
}
</script>
<style scoped>

</style>
