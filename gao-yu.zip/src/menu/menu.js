export const menus = [
    {
        key: '1',
        type: 'mail',
        name: 'Navigation One',
        children: [{
            key: '2',
            type: 'aliwangwang',
            name: 'Navigation two',
            children:[]
        }, {
            key: '3',
            type: 'bulb',
            name: 'Navigation three',
            children:[]
        }]

    }, 
    {
        key: '/user',
        type: 'dashboard',
        name: 'user',
        children:[]
    }



]
